package com.maximgacor.app
import android.Manifest
import android.app.*
import android.content.pm.PackageManager
import android.os.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
private val Y=Color(0xFFFFC400); private val D=Color(0xFF151515); private val P=Color(0xFF252525)
class MainActivity:ComponentActivity(){
 private val ask=registerForActivityResult(ActivityResultContracts.RequestPermission()){}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState)
 if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("mg","MAXIM GACOR",NotificationManager.IMPORTANCE_DEFAULT))
 setContent { MaterialTheme(colorScheme=darkColorScheme(primary=Y,background=D,surface=P)){ Screen({permission()},{test()}) } } }
 private fun permission(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)ask.launch(Manifest.permission.POST_NOTIFICATIONS)}
 private fun test(){permission();if(Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED){val n=NotificationCompat.Builder(this,"mg").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("MAXIM GACOR").setContentText("Notifikasi percobaan berhasil.").build();NotificationManagerCompat.from(this).notify(1,n)}}
}
@Composable fun Screen(permission:()->Unit,test:()->Unit){
 var target by remember{mutableStateOf("20")};var done by remember{mutableStateOf("0")};var city by remember{mutableStateOf("")}
 val g=target.toIntOrNull()?.coerceAtLeast(0)?:0;val d=done.toIntOrNull()?.coerceAtLeast(0)?:0;val p=if(g>0)(d.toFloat()/g).coerceIn(0f,1f)else 0f
 Column(Modifier.fillMaxSize().background(D).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(46.dp).background(Y,RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Text("⚡",color=D,fontSize=25.sp)};Spacer(Modifier.width(10.dp));Column{Text("MAXIM GACOR",color=Y,fontSize=22.sp);Text("AUTO SMART DRIVER • INDONESIA",color=Color.LightGray,fontSize=10.sp)}}
 Text("Dashboard Pengemudi",color=Color.White,fontSize=23.sp);Text("Target: $g | Selesai: $d",color=Y)
 LinearProgressIndicator(progress={p},modifier=Modifier.fillMaxWidth(),color=Y,trackColor=Color.DarkGray)
 OutlinedTextField(target,{target=it},label={Text("Target order harian")},modifier=Modifier.fillMaxWidth())
 OutlinedTextField(done,{done=it},label={Text("Order selesai")},modifier=Modifier.fillMaxWidth())
 OutlinedTextField(city,{city=it},label={Text("Kota / Kabupaten")},modifier=Modifier.fillMaxWidth())
 Button(onClick=permission,modifier=Modifier.fillMaxWidth()){Text("Aktifkan izin notifikasi")}
 OutlinedButton(onClick=test,modifier=Modifier.fillMaxWidth()){Text("Kirim notifikasi percobaan")}
 Text("Prototype awal: belum membaca order Maxim, memantau GPS latar belakang, atau memiliki data keramaian langsung.",color=Color.LightGray,fontSize=11.sp)
 }}
